using System;

namespace UnityEngine.Rendering.PostProcessing {
    [Serializable]
    [PostProcess(typeof(PixelizeRenderer), PostProcessEvent.AfterStack, "Custom/Pixelize")]
    public sealed class Pixelize : PostProcessEffectSettings {
        public IntParameter scaleX = new IntParameter { value = 5 };
        public IntParameter scaleY = new IntParameter { value = 5 };

        public override bool IsEnabledAndSupported(PostProcessRenderContext context) {
            return enabled.value;
        }
    }

    internal sealed class PixelizeRenderer : PostProcessEffectRenderer<Pixelize> {
        public override void Render(PostProcessRenderContext context) {
            var sheet = context.propertySheets.Get(Shader.Find("Hidden/Custom/Pixelize"));
            sheet.properties.Clear();
            sheet.properties.SetInt("_PixelateX", settings.scaleX);
            sheet.properties.SetInt("_PixelateY", settings.scaleY);

            context.command.BlitFullscreenTriangle(context.source, context.destination, sheet, 0);
        }
    }
}